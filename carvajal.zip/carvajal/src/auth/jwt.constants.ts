export const jwtConstants = { secret: 'jwtSecret' };
