import { HttpException, Injectable } from '@nestjs/common';
import { LoginAuthDto } from './dto/login-auth.dto';
import { RegisterAuthDto } from './dto/register-auth.dto';
import { User, UserDocument } from './schema/user.schema';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { hash, compare } from 'bcrypt';
import { filter } from 'rxjs';
import { JwtAuthGuard } from './jwt-auth.guard';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(
    @InjectModel(User.name) private userModel: Model<UserDocument>,
    private jwtService: JwtService,
  ) {}

  async register(userObject: RegisterAuthDto) {
    const { password } = userObject;
    const plainToHas = await hash(password, 10);
    userObject = { ...userObject, password: plainToHas };
    return this.userModel.create(userObject);
  }

  async login(userObjectLogin: LoginAuthDto) {
    // TODO Http request
    const { email, password } = userObjectLogin;
    const findUser = await this.userModel.findOne({ email });

    if (!findUser) throw new HttpException('User Not Found', 404);

    const checkPassword = await compare(password, findUser.password);
    if (!checkPassword) throw new HttpException('Passwords Incorrect', 403);

    const payload = { id: findUser._id, name: findUser.name };
    const token = await this.jwtService.sign(payload);

    const data = { user: findUser, token: token };
    return data;
  }

  create(loginAuthDto: LoginAuthDto) {
    return 'This action adds a new auth';
  }

  findAll() {
    return `This action returns all auth`;
  }

  findOne(id: number) {
    return `This action returns a #${id} auth`;
  }

  update(id: number, loginAuthDto: LoginAuthDto) {
    return `This action updates a #${id} auth`;
  }

  remove(id: number) {
    return `This action removes a #${id} auth`;
  }
}
