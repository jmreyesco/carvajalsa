export class LoginAuthDto {
  email: string;
  password: string;
}
