import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type ItemsDocument = HydratedDocument<User>;

@Schema()
export class User {
  // @Prop() Indica que es una propiedad
  @Prop({ unique: true })
  name: string;

  @Prop()
  email: string;

  @Prop()
  password: string;
}

export const ItemsSchema = SchemaFactory.createForClass(User);
