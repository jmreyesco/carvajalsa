import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type ItemsDocument = HydratedDocument<Items>;

@Schema()
// {timestamps: true,}
export class Items {
  //@Prop() Indica que es una propiedad
  @Prop({ unique: true })
  name: string;

  @Prop()
  title: string;

  // Fazt
  // @Prop({ unique: true, trim: true, required: true })
  // title: string;

  @Prop({ trim: true })
  description: string;

  @Prop({ default: false })
  done: boolean;
}

export const ItemsSchema = SchemaFactory.createForClass(Items);
