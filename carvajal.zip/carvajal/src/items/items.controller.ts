import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  ConflictException,
  NotFoundException,
  HttpCode,
  Put,
} from '@nestjs/common';
import { ItemsService } from './items.service';
import { CreateItemDto } from './dto/create-item.dto';
import { ApiTags } from '@nestjs/swagger';

//Localhost:3000/items
// @ApiTags('items') =  .addTag('items')
@ApiTags('tasks')
@Controller('tasks')
export class ItemsController {
  constructor(private readonly itemsService: ItemsService) {}

  //-****Funcional*********
  // @Post()
  // create(@Body() createItemDto: CreateItemDto) {
  //   return this.itemsService.create(createItemDto);
  // }

  @Get()
  findAll() {
    return this.itemsService.findAll();
  }

  @Post()
  async create(@Body() body: CreateItemDto) {
    try {
      console.log(body);

      return await this.itemsService.create(body);
    } catch (error) {
      if (error.code === 11000) {
        throw new ConflictException('Task already exists', error);
      }
      throw error;
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    const task = await this.itemsService.findOne(id);
    if (!task) throw new NotFoundException('Task does not exist!');
    return task;
  }

  @Delete(':id')
  @HttpCode(204)
  async delete(@Param('id') id: string) {
    const task = await this.itemsService.delete(id);
    if (!task) throw new NotFoundException('Task does not exist!');
    return task;
  }

  @Put(':id')
  async update(@Param('id') id: string, @Body() body: CreateItemDto) {
    const task = await this.itemsService.update(id, body);
    if (!task) throw new NotFoundException('Task does not exist!');
    return task;
  }
}
