import { PartialType } from '@nestjs/mapped-types';
import { CreateItemDto } from './create-item.dto';
import { IsBoolean, IsOptional, IsString, IsNotEmpty } from 'class-validator';

export class UpdateItemDto extends PartialType(CreateItemDto) {
  //   @IsString()
  //   @IsNotEmpty()
  //   title: string;
  //   @IsString()
  //   @IsOptional()
  //   description: string;
  //   @IsBoolean()
  //   @IsOptional()
  //   done?: boolean;
  //   name: string;
  //   age: number;
  //   breed: string;
  // @IsNotEmpty()
  // name: string;
  // @IsNotEmpty()
  // age: number;
  // breed: string;
}
