import { Injectable } from '@nestjs/common';
import { CreateItemDto } from './dto/create-item.dto';
import { UpdateItemDto } from './dto/update-item.dto';
import { Items, ItemsDocument } from './schema/items.schema';
import { ItemsModule } from './items.module';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';

@Injectable()
export class ItemsService {
  constructor(
    @InjectModel(Items.name) private ItemsModule: Model<ItemsDocument>,
  ) {}

  async create(createItemDto: CreateItemDto) {
    // El Dto trae el body en donde esta la data
    const itemCreate = await this.ItemsModule.create(createItemDto);
    return itemCreate;
  }

  async findAll() {
    const list = await this.ItemsModule.find({});
    return list;
  }

  //id:number
  async findOne(id: string) {
    return this.ItemsModule.findById(id).exec();
  }

  // update(id: number, updateItemDto: UpdateItemDto) {
  //   return `This action updates a #${id} item update`;
  // }

  async update(id: string, CreateItemDto: CreateItemDto): Promise<Items> {
    return this.ItemsModule.findByIdAndUpdate(id, CreateItemDto, { new: true });
  }

  async delete(id: string): Promise<Items> {
    return this.ItemsModule.findByIdAndDelete(id);
  }
}
